(function(angular) {
  'use strict';

  // 定义一个模块
  angular.module('moviecat.top250', ['ngRoute', 'moviecat.services.http'])

  .config(['$routeProvider', function($routeProvider) {
    $routeProvider.when('/top250/:page?', {
      templateUrl: 'top250/view.html',
      controller: 'top250Controller'
    });
    // : 代表占位符  ? 代表可选参数
    // /top250/:page  /top250/1
    // /top250/:page  /top250/2
    // /top250/:page  /top250/abc
    //
    // /top250/:page {c:'',t:''}
  }])

  .controller('top250Controller', [
    '$scope',
    '$route',
    '$routeParams',
    'HttpService',
    function($scope, $route, $routeParams, HttpService) {

      var pageSize = 5;

      $scope.page = parseInt($routeParams.page || 1);

      var start = ($scope.page - 1) * 5;

      $scope.title = 'Loading...';
      $scope.movies = [];
      $scope.loading = true;
      $scope.totalCount = 0; // 条数
      $scope.totalPage = 0; // 页数

      // 0 5 10
      // 1 2 3
      HttpService
        .jsonp(
          'http://api.douban.com/v2/movie/top250', { start: start, count: pageSize },
          function(data) {
            $scope.loading = false;
            $scope.title = data.title;
            $scope.movies = data.subjects;
            $scope.totalCount = data.total;
            $scope.totalPage = Math.ceil(data.total / pageSize);
            $scope.$apply(); // 强制同步数据到界面
          }
        );

      // 暴露一个翻页的行为
      $scope.go = function(page) {
        if (0 < page && page < $scope.totalPage + 1)
          $route.updateParams({ page: page });
      };

    }
  ]);

})(angular);



// $http
//   .get('/moviecat/app/data.json')
//   .then((response) => {
//     $scope.movies = response.data;
//   })
//   .catch((err) => {
//     console.log(err);
//   });
// JSON_CALLBACK实际上是一个占位符，最终在请求之前会换成angular.callbacks._0
// jQuery_Callback_8923822937428374
// $http.jsonp('')
