(function(angular) {
  'use strict';

  // 定义一个模块
  angular.module('moviecat.coming_soon', ['ngRoute', 'moviecat.services.http'])

  .config(['$routeProvider', function($routeProvider) {
    $routeProvider.when('/coming_soon/:page?', {
      templateUrl: 'coming_soon/view.html',
      controller: 'coming_soonController'
    });
  }])

  .controller('coming_soonController', [
    '$scope',
    '$routeParams',
    'HttpService',
    function($scope, $routeParams, HttpService) {

      var pageSize = 5;

      $scope.page = parseInt($routeParams.page || 1);

      var start = ($scope.page - 1) * 5;

      $scope.title = 'Loading...';
      $scope.movies = [];
      $scope.loading = true;
      $scope.totalCount = 0; // 条数
      $scope.totalPage = 0; // 页数

      // 0 5 10
      // 1 2 3
      HttpService
        .jsonp(
          'http://api.douban.com/v2/movie/coming_soon',
          { start: start, count: pageSize },
          function(data) {
            $scope.loading = false;
            $scope.title = data.title;
            $scope.movies = data.subjects;
            $scope.totalCount = data.total;
            $scope.totalPage = Math.ceil(data.total / pageSize);
            $scope.$apply(); // 强制同步数据到界面
          }
        );

    }
  ]);

})(angular)



// $http
//   .get('/moviecat/app/data.json')
//   .then((response) => {
//     $scope.movies = response.data;
//   })
//   .catch((err) => {
//     console.log(err);
//   });
// JSON_CALLBACK实际上是一个占位符，最终在请求之前会换成angular.callbacks._0
// jQuery_Callback_8923822937428374
// $http.jsonp('')
